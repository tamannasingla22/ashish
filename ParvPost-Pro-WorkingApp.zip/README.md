# ParvPost Pro App

1. Add Firebase config
2. Open index.html
3. Browse templates, create greetings
4. Save or download your creations!